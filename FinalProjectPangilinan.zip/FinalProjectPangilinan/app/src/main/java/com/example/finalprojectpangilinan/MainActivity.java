package com.example.finalprojectpangilinan;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;
    private Button loginButton;
    private myDbAdapter dbAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        usernameEditText = findViewById(R.id.inputUsername);
        passwordEditText = findViewById(R.id.inputPassword);
        loginButton = findViewById(R.id.loginButton);

        dbAdapter = new myDbAdapter(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    // Show a message if either username or password is empty
                    showToast("Please enter both username and password");
                } else if (username.equals("admin") && password.equals("admin")) {
                    // Admin login
                    navigateToAdminPage();
                    showToast("Login Successful");
                } else {
                    String userType = dbAdapter.getUserType(username, password);
                    if (userType == null) {
                        showToast("Invalid login credentials");
                    } else if (userType.equals("Admin")) {
                        // Admin login
                        navigateToLessAdminPage();
                        showToast("Login Successful");
                    } else if (userType.equals("User")) {
                        // User login
                        navigateToUserPage(username);
                        showToast("Login Successful");
                    }
                }
            }
        });
    }

    private void navigateToAdminPage() {
        Intent intent = new Intent(MainActivity.this, AdminPage.class);
        startActivity(intent);
    }

    private void navigateToLessAdminPage() {
        Intent intent = new Intent(MainActivity.this, lessAdminPage.class);
        startActivity(intent);
    }

    private void navigateToUserPage(String username) {
        Intent intent = new Intent(MainActivity.this, UserPage.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
