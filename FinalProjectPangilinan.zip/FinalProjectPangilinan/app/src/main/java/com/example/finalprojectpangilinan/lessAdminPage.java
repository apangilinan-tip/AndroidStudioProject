package com.example.finalprojectpangilinan;

import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class lessAdminPage extends AppCompatActivity {
    private EditText addUserEditText, addPassEditText, inputDeleteNameEditText;
    private Button addUserButton, viewDataButton, deleteButton, signoutAdminButton;
    private myDbAdapter dbAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.less_admin);

        addUserEditText = findViewById(R.id.addUser);
        addPassEditText = findViewById(R.id.addPass);
        inputDeleteNameEditText = findViewById(R.id.inputDeleteName);
        addUserButton = findViewById(R.id.adduserButton);
        viewDataButton = findViewById(R.id.viewdataButton);
        deleteButton = findViewById(R.id.deleteButton);
        signoutAdminButton = findViewById(R.id.signoutADMIN);

        dbAdapter = new myDbAdapter(this);

        // Add User button click listener
        addUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action for adding a user
                addUser();
            }
        });

        // View Data button click listener
        viewDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action for viewing data
                viewData();
            }
        });

        // Delete button click listener
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action for deleting user
                delete();
            }
        });

        // Sign Out button click listener
        signoutAdminButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show a confirmation dialog before signing out
                showSignOutConfirmationDialog();
            }
        });
    }

    private void addUser() {
        // Get the entered name and password
        String name = addUserEditText.getText().toString();
        String password = addPassEditText.getText().toString();

        // Add the user to the database using the myDbAdapter class
        long id = dbAdapter.insertData(name, password, false); // false means it's a regular user

        // Clear the input fields
        addUserEditText.setText("");
        addPassEditText.setText("");

        // Show a toast or perform any other action based on the insertion result
    }

    private void viewData() {
        // Retrieve and display data from the database using the myDbAdapter class
        String data = dbAdapter.getData();

        // Show the retrieved data in a toast or any other desired way
        Toast.makeText(this, data, Toast.LENGTH_LONG).show();
    }

    private void delete() {
        // Get the name of the user to be deleted
        String nameToDelete = inputDeleteNameEditText.getText().toString();

        // Delete the user from the database using the myDbAdapter class
        int count = dbAdapter.deleteUser(nameToDelete);

        // Clear the input field
        inputDeleteNameEditText.setText("");

        // Show a toast or perform any other action based on the deletion result
    }

    private void showSignOutConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Sign Out");
        builder.setMessage("Are you sure you want to sign out?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Sign out and go back to the login page (MainActivity)
                Intent intent = new Intent(lessAdminPage.this, MainActivity.class);
                startActivity(intent);
                finish(); // Close the lessAdminPage activity
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
