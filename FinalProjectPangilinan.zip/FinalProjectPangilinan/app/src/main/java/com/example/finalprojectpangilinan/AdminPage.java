package com.example.finalprojectpangilinan;

import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminPage extends AppCompatActivity {
    EditText addUserEditText, addPassEditText, inputDeleteNameEditText, inputCurrentEditText, inputNewNameEditText, inputNewPassEditText;
    Button addUserButton, viewDataButton, updateButton, deleteButton;
    RadioGroup userRadioGroup;
    RadioButton adminRadioButton, userRadioButton;
    myDbAdapter dbAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adminpage);

        addUserEditText = findViewById(R.id.addUser);
        addPassEditText = findViewById(R.id.addPass);
        inputDeleteNameEditText = findViewById(R.id.inputDeleteName);
        inputCurrentEditText = findViewById(R.id.inputCurrent);
        inputNewNameEditText = findViewById(R.id.inputNewName);
        inputNewPassEditText = findViewById(R.id.inputNewPassword);
        addUserButton = findViewById(R.id.adduserButton);
        viewDataButton = findViewById(R.id.viewdataButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);
        userRadioGroup = findViewById(R.id.radGroup1);
        adminRadioButton = findViewById(R.id.radButton1);
        userRadioButton = findViewById(R.id.radButton2);

        dbAdapter = new myDbAdapter(this);

        // Add User button click listener
        addUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action for adding a user
                addUser();
            }
        });

        // View Data button click listener
        viewDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action for viewing data
                viewData();
            }
        });

        // Update button click listener
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action for updating user
                update();
            }
        });

        // Delete button click listener
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action for deleting user
                delete();
            }
        });
    }

    public void addUser() {
        // Get the entered name and password
        String name = addUserEditText.getText().toString();
        String password = addPassEditText.getText().toString();

        // Check if the admin or user radio button is selected
        boolean isAdmin = adminRadioButton.isChecked();

        // Add the user to the database using the myDbAdapter class
        long id = dbAdapter.insertData(name, password, isAdmin);

        // Clear the input fields
        addUserEditText.setText("");
        addPassEditText.setText("");

        // Show a toast or perform any other action based on the insertion result
    }

    public void viewData() {
        // Retrieve and display data from the database using the myDbAdapter class
        String data = dbAdapter.getData();

        // Show the retrieved data in a toast or any other desired way
        Toast.makeText(this, data, Toast.LENGTH_LONG).show();
    }

    public void update() {
        // Get the current name, new name, and new password
        String currentName = inputCurrentEditText.getText().toString();
        String newName = inputNewNameEditText.getText().toString();
        String newPassword = inputNewPassEditText.getText().toString(); // Change this line

        // Update the user in the database using the myDbAdapter class
        int count = dbAdapter.updateUser(currentName, newName, newPassword);

        // Clear the input fields
        inputCurrentEditText.setText("");
        inputNewNameEditText.setText("");
        inputNewPassEditText.setText(""); // Clear the new password input field as well

        if (count > 0) {
            Toast.makeText(this, "User updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to update user", Toast.LENGTH_SHORT).show();
        }
        // Show a toast or perform any other action based on the update result
    }


    public void delete() {
        // Get the name of the user to be deleted
        String nameToDelete = inputDeleteNameEditText.getText().toString();

        // Delete the user from the database using the myDbAdapter class
        int count = dbAdapter.deleteUser(nameToDelete);

        // Clear the input field
        inputDeleteNameEditText.setText("");

        // Show a toast or perform any other action based on the deletion result
    }

    public void signOut(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Sign Out");
        builder.setMessage("Are you sure you want to sign out?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(AdminPage.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

}
