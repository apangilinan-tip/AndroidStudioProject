package com.example.finalprojectpangilinan;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class myDbAdapter {
    private static final String DATABASE_NAME = "myDatabase";
    private static final String TABLE_NAME = "myTable";
    private static final int DATABASE_VERSION = 1;
    private static final String UID = "_id";
    private static final String NAME = "Name";
    private static final String MyPASSWORD = "Password";
    private static final String IS_ADMIN = "IsAdmin";
    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME +
            " (" + UID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + NAME + " VARCHAR(255), " +
            MyPASSWORD + " VARCHAR(225), " + IS_ADMIN + " INTEGER);";
    private static final String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME;

    private Context context;
    private myDbHelper myhelper;

    public myDbAdapter(Context context) {
        this.context = context;
        myhelper = new myDbHelper(context);
    }

    public boolean verifyUserLogin(String username, String password) {
        SQLiteDatabase db = myhelper.getReadableDatabase();
        String[] columns = {UID};
        String selection = NAME + " = ? COLLATE BINARY AND " + MyPASSWORD + " = ? COLLATE BINARY AND " + IS_ADMIN + " = ?";
        String[] selectionArgs = {username, password, "0"}; // "0" means user, "1" means admin
        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);

        boolean loginSuccessful = cursor.moveToFirst();
        cursor.close();
        return loginSuccessful;
    }

    public long insertData(String name, String pass, boolean isAdmin) {
        SQLiteDatabase dbb = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NAME, name);
        contentValues.put(MyPASSWORD, pass);
        contentValues.put(IS_ADMIN, isAdmin ? 1 : 0);
        long id = dbb.insert(TABLE_NAME, null, contentValues);
        return id;
    }

    public String getData() {
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {UID, NAME, MyPASSWORD, IS_ADMIN};
        Cursor cursor = db.query(TABLE_NAME, columns, null, null, null, null, null);
        StringBuffer buffer = new StringBuffer();
        while (cursor.moveToNext()) {
            int cidIndex = cursor.getColumnIndex(UID);
            int cid = (cidIndex != -1) ? cursor.getInt(cidIndex) : 0;

            int nameIndex = cursor.getColumnIndex(NAME);
            String name = (nameIndex != -1) ? cursor.getString(nameIndex) : "";

            int passwordIndex = cursor.getColumnIndex(MyPASSWORD);
            String password = (passwordIndex != -1) ? cursor.getString(passwordIndex) : "";

            int isAdminIndex = cursor.getColumnIndex(IS_ADMIN);
            int isAdmin = (isAdminIndex != -1) ? cursor.getInt(isAdminIndex) : 0;

            String userType = isAdmin == 1 ? "Admin" : "User";
            buffer.append(cid + "   " + name + "   " + password + "   " + userType + " \n");
        }
        return buffer.toString();
    }

    public String getUserType(String username, String password) {
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {IS_ADMIN};
        String selection = NAME + " = ? AND " + MyPASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        String userType = null;
        if (cursor != null && cursor.moveToFirst()) {
            int isAdminIndex = cursor.getColumnIndex(IS_ADMIN);
            int isAdmin = cursor.getInt(isAdminIndex);
            userType = isAdmin == 1 ? "Admin" : "User";
            cursor.close();
        }
        return userType;
    }

    public int deleteUser(String uname) {
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] whereArgs = {uname};
        int count = db.delete(TABLE_NAME, NAME + " = ?", whereArgs);
        return count;
    }

    public int updateUser(String oldName, String newName, String newPassword) {
        SQLiteDatabase db = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NAME, newName);
        contentValues.put(MyPASSWORD, newPassword);
        String[] whereArgs = {oldName};
        int count = db.update(TABLE_NAME, contentValues, NAME + " = ?", whereArgs);
        return count;
    }

    static class myDbHelper extends SQLiteOpenHelper {
        private Context context;

        public myDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            this.context = context;
        }

        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(CREATE_TABLE);
            } catch (Exception e) {
                Message.message(context, "" + e);
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                Message.message(context, "OnUpgrade");
                db.execSQL(DROP_TABLE);
                onCreate(db);
            } catch (Exception e) {
                Message.message(context, "" + e);
            }
        }
    }
}

