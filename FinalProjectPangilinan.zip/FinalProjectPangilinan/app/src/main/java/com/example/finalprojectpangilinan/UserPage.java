package com.example.finalprojectpangilinan;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UserPage extends AppCompatActivity {
    Button signOutButton;
    TextView welcomeTextView;
    TextView usernameTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userpage);

        // Find the TextViews for displaying the welcome message and the username
        welcomeTextView = findViewById(R.id.welcomeTextView);
        usernameTextView = findViewById(R.id.usernameTextView);

        // Retrieve the username from the intent
        String username = getIntent().getStringExtra("username");
        // Use the username as needed in your UserPage activity

        usernameTextView.setText("Hello, " + username);

        signOutButton = findViewById(R.id.signoutButton);
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show an AlertDialog when "Sign Out" button is clicked
                showSignOutAlertDialog();
            }
        });
    }

    private void showSignOutAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Sign Out")
                .setMessage("Are you sure you want to sign out?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Perform sign out action
                        signOut();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void signOut() {
        // Perform sign out functionality here

        // Navigate back to MainActivity
        Intent intent = new Intent(UserPage.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Clear the activity stack
        startActivity(intent);
    }
}
